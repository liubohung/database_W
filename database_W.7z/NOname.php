<?php // login.php
	$hn = 'localhost';
	$db = 'class_database';
	$connect_un = 'NOname';
	$connect_pw = 'Nopasswordlogin111';
?>