<?php // login.php
	$hn = 'localhost';
	$db = 'class_database';
	$connect_un = 'liu';
	$connect_pw = 'iwanttologin';
?>